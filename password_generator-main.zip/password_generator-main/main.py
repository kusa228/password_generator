import random
import string
import sqlite3

from fastapi import FastAPI, Request, Form
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

app = FastAPI()

# STATIC FILES
app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")

# DATABASE

connection = sqlite3.connect(
    "database.db",
    check_same_thread=False
)

cursor = connection.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS passwords (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    password TEXT,
    strength TEXT
)
""")

connection.commit()


# HOME PAGE
@app.get("/")
async def home(request: Request):

    # GET HISTORY

    cursor.execute("""
    SELECT password, strength
    FROM passwords
    ORDER BY id DESC
    LIMIT 5
    """)

    history = cursor.fetchall()

    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "password": "Your password",
            "strength": "Medium",
            "length": 12,
            "history": history
        }
    )


# GENERATE PASSWORD
@app.post("/generate")
async def generate_password(
        request: Request,
        length: int = Form(...),
        numbers: str = Form(None),
        symbols: str = Form(None),
        uppercase: str = Form(None),
        lowercase: str = Form(None)
):

    characters = ""

    # ADD CHARACTER TYPES

    if numbers:
        characters += string.digits

    if symbols:
        characters += string.punctuation

    if uppercase:
        characters += string.ascii_uppercase

    if lowercase:
        characters += string.ascii_lowercase

    # DEFAULT OPTION

    if characters == "":
        characters = string.ascii_letters

    # GENERATE PASSWORD

    password = "".join(
        random.choice(characters)
        for _ in range(length)
    )

    # PASSWORD STRENGTH

    if length < 8:
        strength = "Weak"

    elif length < 14:
        strength = "Medium"

    else:
        strength = "Strong"

    # SAVE TO DATABASE

    cursor.execute(
        """
        INSERT INTO passwords (password, strength)
        VALUES (?, ?)
        """,
        (password, strength)
    )

    connection.commit()

    # GET HISTORY

    cursor.execute("""
    SELECT password, strength
    FROM passwords
    ORDER BY id DESC
    LIMIT 5
    """)

    history = cursor.fetchall()

    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "password": password,
            "strength": strength,
            "length": length,
            "history": history
        }
    )