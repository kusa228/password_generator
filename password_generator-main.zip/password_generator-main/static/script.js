const slider = document.getElementById("length-slider");
const lengthValue = document.getElementById("length-value");

// SLIDER

slider.addEventListener("input", () => {
    lengthValue.textContent = slider.value;
});


// COPY BUTTON

const copyBtn = document.getElementById("copy-btn");
const passwordOutput = document.getElementById("password-output");

copyBtn.addEventListener("click", async () => {

    const password = passwordOutput.textContent.trim();

    try {

        await navigator.clipboard.writeText(password);

        copyBtn.textContent = "Copied!";

        setTimeout(() => {
            copyBtn.textContent = "Copy";
        }, 1500);

    } catch (error) {

        console.log("Copy error:", error);

    }

});